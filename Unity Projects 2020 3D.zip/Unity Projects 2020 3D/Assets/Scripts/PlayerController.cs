﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    CharacterController controller;
    public float moveSpeed;
    public float jumpForce;
    public float gravity;
    bool jump;
    Vector3 movement;
    public bool canDoubleJump;
    int jumpCounter;

    Vector3 mousePos;
    Vector3 playerPos;
    Vector3 direction;


    private void Awake()
    {
        controller = GetComponent<CharacterController>();

    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {



        if (Input.GetButtonDown("Jump") && !jump)
        {
            jump = true;

        }

        mousePos = Input.mousePosition;
        playerPos = Camera.main.WorldToScreenPoint(transform.position);
        direction = mousePos - playerPos;

        float rotationAngle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;

        transform.rotation = Quaternion.AngleAxis(-rotationAngle, Vector3.up);

    }

    private void FixedUpdate()
    {

        movement.x = Input.GetAxis("Horizontal") * moveSpeed;
        movement.z = Input.GetAxis("Vertical") * moveSpeed;

        


        if (!controller.isGrounded)
        {
            //moving up
            if(movement.y > 0) 
            {
                
                movement.y -= gravity;

            }
            //falling
            else
            {
                movement.y -= gravity * 1.5f;
            }
            
        }
        else
        {
            movement.y = 0;
        }
        if (jump)
        {
            movement.y = jumpForce;
            jump = false;
        }
        

        controller.Move(movement);

    }




}
