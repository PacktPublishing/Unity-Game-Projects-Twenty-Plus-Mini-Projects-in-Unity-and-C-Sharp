﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollwer : MonoBehaviour
{

    public Transform player;
    public float smoothRate;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    private void FixedUpdate()
    {
        Vector3 playerPos = player.position;
        Vector3 cameraPos = transform.position;

        //cameraPos.x = playerPos.x;
        cameraPos.x = Mathf.Lerp(cameraPos.x, playerPos.x, smoothRate);

        transform.position = cameraPos;

    }
}
