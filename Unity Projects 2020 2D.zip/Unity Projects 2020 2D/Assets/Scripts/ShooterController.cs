﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShooterController : MonoBehaviour
{
    Vector3 mousePosition;
    Vector2 direction;

    public GameObject crosshair;
    public GameObject bullet;

    public Transform shootPosition;

    // Start is called before the first frame update
    void Start()
    {
        Cursor.visible = false;
    }

    // Update is called once per frame
    void Update()
    {
        mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        crosshair.transform.position = new Vector3(mousePosition.x, mousePosition.y, 0);

        direction = mousePosition - transform.position;

        transform.up = direction;

        if (Input.GetMouseButtonDown(0))
        {
            Fire();
        }

    }

    void Fire()
    {
        Instantiate(bullet, shootPosition.position, transform.rotation);
    }
}
